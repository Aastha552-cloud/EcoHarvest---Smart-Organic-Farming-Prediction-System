# Student Name: Aastha Singh
# Student ID: BWU/BCA/24/552
# Course Name: ML
# Course ID: BCA57205

# Organic Farming Suitability Prediction - Python script
# Run in Google Colab after uploading the CSV, or locally with the CSV in the same folder.
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, classification_report

FILE_NAME = 'organic_farming_suitability_1000_source_calibrated.csv'
df = pd.read_csv(FILE_NAME)
print('Shape:', df.shape)
print(df.head())
print(df.info())
print(df.isnull().sum())

# EDA
print(df['Organic_Farming_Suitability'].value_counts())
sns.countplot(data=df, x='Organic_Farming_Suitability')
plt.title('Suitability class distribution'); plt.tight_layout(); plt.show()

# Exclude ID and Suitability_Score to avoid target leakage because the dataset note says
# the category is derived from the score.
X = df.drop(columns=['Sample_ID', 'Suitability_Score', 'Organic_Farming_Suitability'])
y = df['Organic_Farming_Suitability'].map({'Not Suitable': 0, 'Suitable': 1})
num_cols = X.select_dtypes(include=np.number).columns.tolist()
cat_cols = X.select_dtypes(exclude=np.number).columns.tolist()
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
num_scaled = Pipeline([('imputer', SimpleImputer(strategy='median')), ('scaler', StandardScaler())])
cat_pipe = Pipeline([('imputer', SimpleImputer(strategy='most_frequent')), ('onehot', OneHotEncoder(handle_unknown='ignore'))])
prep_scaled = ColumnTransformer([('num', num_scaled, num_cols), ('cat', cat_pipe, cat_cols)])
prep_tree = ColumnTransformer([('num', SimpleImputer(strategy='median'), num_cols), ('cat', cat_pipe, cat_cols)])
models = {
 'Logistic Regression': Pipeline([('prep', prep_scaled), ('model', LogisticRegression(max_iter=2000))]),
 'Decision Tree': Pipeline([('prep', prep_tree), ('model', DecisionTreeClassifier(random_state=42, max_depth=6))]),
 'Random Forest': Pipeline([('prep', prep_tree), ('model', RandomForestClassifier(n_estimators=300, random_state=42, class_weight='balanced'))]),
 'K-Nearest Neighbors': Pipeline([('prep', prep_scaled), ('model', KNeighborsClassifier(n_neighbors=7))])
}
results=[]
for name, model in models.items():
    model.fit(X_train, y_train)
    pred=model.predict(X_test)
    prob=model.predict_proba(X_test)[:, 1]
    results.append({'Model':name, 'Accuracy':accuracy_score(y_test,pred), 'Precision':precision_score(y_test,pred,zero_division=0), 'Recall':recall_score(y_test,pred,zero_division=0), 'F1-score':f1_score(y_test,pred,zero_division=0), 'ROC-AUC':roc_auc_score(y_test,prob)})
    print('\\n', name)
    print(classification_report(y_test,pred,target_names=['Not Suitable','Suitable'],zero_division=0))
    sns.heatmap(confusion_matrix(y_test,pred), annot=True, fmt='d', cmap='Blues')
    plt.title('Confusion Matrix - '+name); plt.xlabel('Predicted'); plt.ylabel('Actual'); plt.show()
results_df=pd.DataFrame(results).sort_values('F1-score',ascending=False)
print(results_df)
results_df.to_csv('model_comparison_results.csv',index=False)
print('Saved model_comparison_results.csv')
